package dessertation.thesis.projectpredict;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private EditText inputEmail, inputPassword, name, address, state, phone;
    private Button btnSignUp;
    private ProgressBar progressBar;
    private FirebaseAuth auth;

    DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        mDatabase = FirebaseDatabase.getInstance().getReference("usersprofile");

        auth = FirebaseAuth.getInstance();
        //mDatabase = FirebaseDatabase.getInstance().getReference().child(glory);

        btnSignUp = (Button) findViewById(R.id.btn_register);
        inputEmail = (EditText) findViewById(R.id.email_reg);
        name = (EditText) findViewById(R.id.fullname);
        address = (EditText) findViewById(R.id.address);
        inputPassword = (EditText) findViewById(R.id.password_reg);
        state = (EditText) findViewById(R.id.state);
        phone = (EditText) findViewById(R.id.phone_reg);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String email = inputEmail.getText().toString().trim();
                final String password = inputPassword.getText().toString().trim();
                final String contact = phone.getText().toString().trim();
                final String full_name = name.getText().toString().trim();
                final String hous_address = address.getText().toString().trim();
                final String state_location = state.getText().toString().trim();

                if (TextUtils.isEmpty(full_name)) {
                    Toast.makeText(getApplicationContext(), "Enter your Full Names!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(hous_address)) {
                    Toast.makeText(getApplicationContext(), "Enter your Postal Address!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(state_location)) {
                    Toast.makeText(getApplicationContext(), "Enter the State where you live!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(contact)) {
                    Toast.makeText(getApplicationContext(), "Enter a Valid Phone number!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(getApplicationContext(), "Enter email address!", Toast.LENGTH_SHORT).show();
                    return;
                }


                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(getApplicationContext(), "Enter password!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (password.length() < 6) {
                    Toast.makeText(getApplicationContext(), "Password too short, enter minimum 6 characters!", Toast.LENGTH_SHORT).show();
                    return;
                }

                progressBar.setVisibility(View.VISIBLE);
                //create user
                auth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                Toast.makeText(RegisterActivity.this, "Welcome", Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                                // If sign in fails, display a message to the user. If sign in succeeds
                                // the auth state listener will be notified and logic to handle the
                                // signed in user can be handled in the listener.
                                if (!task.isSuccessful()) {
                                    Toast.makeText(RegisterActivity.this, "Authentication failed." + task.getException(),
                                            Toast.LENGTH_SHORT).show();
                                } else {
                                    //String user_Id = auth.getCurrentUser().getUid();
                                    // DatabaseReference current_User = mDatabase.child(user_Id);
                                    //current_User.child("User").setValue(email);
                                    String id = mDatabase.push().getKey();
                                    userupdate(id,full_name,hous_address,state_location, contact, email,password);

                                    // UserApp data = new UserApp(id, email, contact);

                                    //  mDatabase.child(id).setValue(data);

                                        startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                                        finish();



                                }
                            }
                        });

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);
    }

    private boolean userupdate(final String id, final String getusername, final String gethomeaddress, final String getlocation, final String getmobile, final String getuseremail, final String getuserpassword){

        //String id = reference.push().getKey();

        //DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Book");
        UserApp data = new UserApp(id,getusername, gethomeaddress, getlocation,getmobile, getuseremail,getuserpassword);
        mDatabase.child(id).setValue(data)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Write was successful!
                        // ...
                        Toast.makeText(RegisterActivity.this, "Details Saved Succesfully", Toast.LENGTH_SHORT).show();
                        // check = "true";
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Write failed
                        // ...
                        Toast.makeText(RegisterActivity.this, "Error in Profile Update", Toast.LENGTH_SHORT).show();
                    }
                });

        //databaseReference.child(id).setValue(data);
        return true;
    }

}
