package dessertation.thesis.projectpredict;


import com.google.firebase.database.IgnoreExtraProperties;

@IgnoreExtraProperties
public class UserApp {


    public String userid;
    public String username;
    public String homeaddress;
    public String location;
    public String mobile;
    public String useremail;
    public String userpassword;

    public UserApp() {
    }

    public UserApp(String userid, String username, String homeaddress, String location, String mobile, String useremail, String userpassword) {
        this.userid = userid;
        this.username = username;
        this.homeaddress = homeaddress;
        this.location = location;
        this.mobile = mobile;
        this.useremail = useremail;
        this.userpassword = userpassword;
    }

    public String getUserid() {
        return userid;
    }

    public String getUsername() {
        return username;
    }

    public String getHomeaddress() {
        return homeaddress;
    }

    public String getLocation() {
        return location;
    }

    public String getMobile() {
        return mobile;
    }

    public String getUseremail() {
        return useremail;
    }

    public String getUserpassword() {
        return userpassword;
    }

}
