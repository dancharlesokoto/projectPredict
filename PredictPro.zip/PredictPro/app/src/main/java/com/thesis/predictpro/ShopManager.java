package com.thesis.predictpro;

import android.app.Application;


public class ShopManager extends Application {
    @Override
    public void onCreate() {
       super.onCreate();


    }

}
